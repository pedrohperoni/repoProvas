/// <reference types="react-scripts" />

declare module "@material-ui/core/styles" {
  interface Theme {}
  // allow configuration using `createTheme`
  interface ThemeOptions {}
}
